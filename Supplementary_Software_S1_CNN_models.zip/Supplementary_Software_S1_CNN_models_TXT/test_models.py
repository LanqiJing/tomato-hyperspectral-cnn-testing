"""Test any or all three CNN families using their supplied trained weights."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from scipy.signal import savgol_filter

from models import load_model

ROOT = Path(__file__).resolve().parent
TARGETS = ['SOD', 'CAT', 'APX']
MODELS = ['ST-CNN', 'MT-CNN', 'MT-CNN-TA']


def preprocess(raw, scaling_path):
    x = np.asarray(raw, dtype=np.float32)
    if x.ndim != 2 or x.shape[1] != 176 or not np.isfinite(x).all():
        raise ValueError('Expected finite raw calibrated reflectance with 176 bands.')
    x = savgol_filter(x, 11, polyorder=2, deriv=0, axis=1).astype(np.float32)
    x = ((x - x.mean(1, keepdims=True)) / (x.std(1, keepdims=True) + 1e-8)).astype(np.float32)
    with np.load(scaling_path, allow_pickle=False) as s:
        x -= s['x_mean']
        x /= s['x_scale']
        y_mean, y_scale = s['y_mean'].copy(), s['y_scale'].copy()
    return x, y_mean, y_scale


def predict(model_name, raw):
    folder = ROOT / 'weights' / model_name
    x, means, scales = preprocess(raw, folder / 'preprocessing.npz')
    with torch.inference_mode():
        if model_name == 'ST-CNN':
            outputs = []
            for name in TARGETS:
                net = load_model(model_name, folder / f'{name}.pth')
                batches = [np.asarray(net(torch.tensor(x[i:i+256])).tolist(), dtype=np.float32)
                           for i in range(0, len(x), 256)]
                outputs.append(np.concatenate(batches).ravel())
            scaled = np.column_stack(outputs)
        else:
            net = load_model(model_name, folder / 'best_model.pth')
            scaled = np.concatenate([
                np.asarray(net(torch.tensor(x[i:i+256])).tolist(), dtype=np.float32)
                for i in range(0, len(x), 256)])
    result = np.empty_like(scaled)
    for i in range(3):
        result[:, i] = scaled[:, i]
        result[:, i] *= scales[i]
        result[:, i] += means[i]
    return result


def run(input_path=None, output_dir=None, model_name='all'):
    torch.set_num_threads(1)
    table = pd.read_csv(input_path or ROOT / 'data' / 'spectra.txt', sep='\t')
    columns = [f'band_{i:03d}' for i in range(1, 177)]
    if not all(c in table for c in columns) or table.empty:
        raise ValueError('Missing band columns or no input samples.')
    raw = table[columns].to_numpy(dtype=np.float32)
    destination = Path(output_dir) if output_dir else ROOT / 'outputs'
    destination.mkdir(parents=True, exist_ok=True)
    rows = []
    all_predictions = {}
    for model in MODELS if model_name == 'all' else [model_name]:
        pred = predict(model, raw)
        all_predictions[model] = pred
        result = table[[c for c in ['sample_id', 'original_index', 'split'] if c in table]].copy()
        for i, target in enumerate(TARGETS):
            result[f'{target}_pred'] = pred[:, i]
            if target in table:
                true = table[target].to_numpy(dtype=np.float64)
                if not np.isfinite(true).all():
                    raise ValueError(f'Invalid labels: {target}')
                error = pred[:, i].astype(np.float64) - true
                rmse = np.sqrt(np.mean(error ** 2))
                denominator = np.sum((true - true.mean()) ** 2)
                rows.append(dict(model=model, target=target, n=len(true),
                                 R2=1-np.sum(error**2)/denominator if denominator > 0 else np.nan,
                                 RMSE=rmse, MAE=np.mean(np.abs(error)),
                                 RPD=np.std(true, ddof=1)/rmse if len(true)>1 and rmse>0 else np.nan))
                result[f'{target}_true'] = true
        result.to_csv(destination / f'{model}_predictions.txt', sep='\t', index=False)
    metrics = pd.DataFrame(rows)
    if len(metrics):
        metrics.to_csv(destination / 'metrics.txt', sep='\t', index=False)
        print(metrics.to_string(index=False))
    print(f'Output directory: {destination.resolve()}')
    return table, all_predictions, metrics


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', choices=['all']+MODELS, default='all')
    parser.add_argument('--input', type=Path, help='Optional tab-delimited TXT with 176 raw reflectance bands.')
    parser.add_argument('--output-dir', type=Path)
    args = parser.parse_args()
    run(args.input, args.output_dir, args.model)
