 Supplementary Software S1: Trained CNN models and testing instructions

This package contains the weights and minimal inference materials needed to test ST-CNN, MT-CNN, and MT-CNN-TA for simultaneous estimation of SOD, CAT, and APX activities in tomato leaves under salt stress. ST-CNN uses three separately trained models; each multitask model uses one checkpoint with three outputs. No retraining is required. 

Contents

weights/ST-CNN/SOD.pth, CAT.pth, APX.pth: the three single-task checkpoints.
weights/MT-CNN/best_model.pth: the multitask checkpoint.
weights/MT-CNN-TA/best_model.pth: the multitask checkpoint with task-level attention.
weights/*/preprocessing.npz: fixed training-only feature and target scaling parameters.
models.py: architecture definitions and weight loading.
test_models.py: spectral preprocessing, inference, and metric calculation.
data/spectra.txt: only the original 58 held-out leaf samples, including calibrated reflectance and measured target values.
data/feature_order.txt: mapping of 176 band columns to the original workbook headers.
reference_results/: expected test predictions and metrics.
model_config.json: model and preprocessing settings.
requirements.txt: software versions used in verification.
verification_report.json: numerical verification against archived test predictions.
SHA256SUMS.txt: package file integrity hashes.

 Installation

The verified environment uses Python 3.9.25, PyTorch 1.13.1 on CPU, NumPy 1.26.4, pandas 2.3.3, and SciPy 1.13.1. Use a Python 3.9 environment for the closest reproduction. No GPU is required. In the extracted package folder:

bash
python -m venv .venv
Windows:
.venv\Scripts\activate
macOS/Linux instead: source .venv/bin/activate
python -m pip install -r requirements.txt

 Test all three CNN model families

bash
python test_models.py


The script reads the supplied 58 test spectra, loads all five checkpoints, and predicts SOD, CAT, and APX. It writes `outputs/metrics.txt` and one prediction tab-delimited TXT for each model family. The metrics are R2, RMSE, MAE, and RPD. Existing output files with the same names in the selected directory are overwritten on rerun. Inputs are resolved relative to the script, so testing also works from a different working directory.

Expected test results, rounded to four decimal places:

| Model | Target | R2 | RMSE | MAE | RPD |
|---|---|---:|---:|---:|---:|
| ST-CNN | SOD | 0.8072 | 8.5898 | 7.1295 | 2.2972 |
| ST-CNN | CAT | 0.8211 | 6.2543 | 4.7891 | 2.3852 |
| ST-CNN | APX | 0.7631 | 0.1175 | 0.0931 | 2.0725 |
| MT-CNN | SOD | 0.8342 | 7.9662 | 6.4583 | 2.4770 |
| MT-CNN | CAT | 0.8543 | 5.6456 | 4.3167 | 2.6424 |
| MT-CNN | APX | 0.7657 | 0.1169 | 0.0896 | 2.0841 |
| MT-CNN-TA | SOD | 0.8929 | 6.4020 | 4.6807 | 3.0822 |
| MT-CNN-TA | CAT | 0.8749 | 5.2305 | 3.7094 | 2.8521 |
| MT-CNN-TA | APX | 0.8129 | 0.1044 | 0.0766 | 2.3323 |

RPD is the sample standard deviation of measured values (`ddof=1`) divided by RMSE. Predictions, RMSE, and MAE use the original measured target scales and units defined in the manuscript. No unit conversion is applied. Small floating-point differences can occur across environments. Archived predictions and reconstructed outputs were compared using `rtol=1e-5, atol=1e-4`; see `verification_report.json`. Match reference rows using `original_index`, a zero-based index in the original workbook.

Test one model family

bash
python test_models.py --model ST-CNN --output-dir outputs/st_cnn
python test_models.py --model MT-CNN --output-dir outputs/mt_cnn
python test_models.py --model MT-CNN-TA --output-dir outputs/mt_cnn_ta

Predict new spectra

bash
python test_models.py --input new_spectra.txt --output-dir outputs/new_samples


Each row must contain calibrated reflectance before SG, SNV, or standardization, with columns `band_001` through `band_176` in the acquisition order mapped in data/feature_order.txt. Preserve the original reflectance scale and wavelength grid. Optional `SOD`, `CAT`, and `APX` columns enable evaluation; otherwise only predictions are saved. The script does not read RGB images, uncalibrated detector counts, or raw hyperspectral scenes, and does not perform wavelength interpolation.

The inference pipeline applies Savitzky-Golay smoothing (window 11, polynomial order 2, derivative 0), per-spectrum SNV (population standard deviation, epsilon 1e-8), and the fixed training feature scaler. Model outputs are inverse-transformed with the saved target scalers. No scaler is fitted to the supplied test data or new samples.

Task-level attention

MT-CNN-TA applies attention to the 64-dimensional feature vector after the fully connected ReLU layer and before Dropout and the joint output layer. Its gate is Linear(64,8), ReLU, Linear(8,64), and Sigmoid, followed by element-wise multiplication with that feature vector. It does not directly weight the original 176 wavelength channels. Checkpoint tensor values are preserved; the attention key prefix uses `task_ta` consistently with `models.py`.

This package supports verification of the main leaf-level CNN comparison. It does not include independently trained leave-one-time-point checkpoints or raw spatial hyperspectral scenes. No public database deposit or DOI is asserted by this package; it is prepared for submission as Supplementary Software S1.
