"""Architectures for ST-CNN, MT-CNN, and MT-CNN-TA."""
import torch
from torch import nn


class TaskAttention(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 8)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(8, 64)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        return x * self.sigmoid(self.fc2(self.relu(self.fc1(x))))


class SpectralCNN(nn.Module):
    def __init__(self, model_name, bands=176):
        super().__init__()
        if model_name not in ['ST-CNN', 'MT-CNN', 'MT-CNN-TA']:
            raise ValueError(model_name)
        self.model_name = model_name
        self.encoder = nn.Sequential(
            nn.Conv1d(1, 32, 5, padding=2), nn.BatchNorm1d(32), nn.ReLU(),
            nn.MaxPool1d(2), nn.Dropout(.3),
            nn.Conv1d(32, 64, 5, padding=2), nn.BatchNorm1d(64), nn.ReLU(),
            nn.MaxPool1d(2), nn.Dropout(.3),
        )
        if model_name == 'MT-CNN-TA':
            self.task_features = nn.Sequential(nn.Linear((bands // 4) * 64, 64), nn.ReLU())
            self.task_ta = TaskAttention()
            self.task_dropout = nn.Dropout(.3)
            self.task_output = nn.Linear(64, 3)
        else:
            outputs = 1 if model_name == 'ST-CNN' else 3
            self.head = nn.Sequential(nn.Linear((bands // 4) * 64, 64), nn.ReLU(),
                                      nn.Dropout(.3), nn.Linear(64, outputs))

    def forward(self, x):
        x = self.encoder(x.unsqueeze(1)).flatten(1)
        if self.model_name == 'MT-CNN-TA':
            return self.task_output(self.task_dropout(self.task_ta(self.task_features(x))))
        return self.head(x)


def load_model(model_name, weights, bands=176):
    model = SpectralCNN(model_name, bands)
    model.load_state_dict(torch.load(weights, map_location='cpu', weights_only=True), strict=True)
    return model.eval()
